#include <iostream>
#include <cmath>

using namespace std;

int main(){
    float a, raiz;
    cin >> a;
    raiz=sqrt(a);

    cout << "O raiz do número "<< a << " é " << raiz <<  endl;
}
