#include <iostream>

using namespace std;

int main(){
    float a,quadrado;
    cin >> a;
    quadrado=(a*a);

    cout << "O quadrado do número "<< a << " é  " << quadrado<<  endl;
}
