#include <iostream>

using namespace std;

int main(){
    float a=2.5, b=3.5, c=1.0, media;
    
    media=(a+b+c)/3;

    cout << "O valor da média entre 2.5, 3.5 e 1 é "<< media <<  endl;
}
