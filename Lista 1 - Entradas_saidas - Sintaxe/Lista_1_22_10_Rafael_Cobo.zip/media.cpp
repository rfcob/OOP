#include <iostream>

using namespace std;

int main(){
    int a=2, b=3, c=4, media;
    
    media=(a+b+c)/3;

    cout << "O valor da média entre 2, 3 e 4 é "<< media <<  endl;
}
