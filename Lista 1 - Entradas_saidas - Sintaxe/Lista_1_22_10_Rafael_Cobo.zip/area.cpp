#include <iostream>

using namespace std;

int main(){
    float a, b, area;
    cin >> a;
    cin >> b;
    area=(a*b);

    cout << "A área do quadra é: "<< area<<  endl;
}
