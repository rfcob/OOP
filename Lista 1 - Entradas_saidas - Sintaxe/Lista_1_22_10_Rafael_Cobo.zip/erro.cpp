#include <iostream>  
using namespace std;  

int main( ) {  
 int idade;  
 idade = 5;  
 cout << "Minha idade é: " << idade << endl;  
 idade = ‘i’;  
 cout << idade << endl;  
}  

